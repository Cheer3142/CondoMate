# CondoMate — Phase 1 MVP

React + Vite, responsive web, installable as a PWA. No native app in Phase 1.

## Run it

```bash
npm install
npm run dev
```

Open the printed local URL. On a phone on the same network, open the URL and
use "Add to Home Screen" — it installs and runs full-screen like an app.

```bash
npm run build     # production build, output in dist/
npm run preview   # serve the production build locally
```

## What's in Phase 1

- `/` — pick resident or admin (stand-in for real login/roles later)
- `/resident/*` — home, แจ้งซ่อม, พัสดุ, ประกาศ, จองพื้นที่ส่วนกลาง (5 tabs, phone-shaped layout)
- `/admin/*` — Dashboard, แจ้งซ่อม, พัสดุ, ประกาศ, ส่วนกลาง, ลูกบ้าน (sidebar, desktop-shaped layout)

All data lives in `src/data/store.jsx`, backed by `localStorage` under the key
`condomate.v1` so it survives a page refresh during development/demos. There
is no server yet — resident and admin share the same in-browser state, which
is why updating a repair ticket's status in the admin view is reflected
immediately on the resident side.

## Before this is real

- **Auth**: `CURRENT_ROOM` / `CURRENT_NAME` in `src/data/store.jsx` are
  hardcoded to one unit. Replace with real login (resident vs. นิติบุคคล
  role) before this goes further.
- **Backend**: every action in `src/data/store.jsx` (`addTicket`,
  `updateTicket`, `ackParcel`, …) currently just updates local state. Swap
  each one for a `fetch()` call to your API — the rest of the app calls
  `useData()` and doesn't need to change.
- **Push notifications**: parcel/status updates only appear when the app is
  open. Real-time alerts need either polling, WebSockets, or Web Push —
  none are wired up yet.
- **Icons**: `public/icons/icon.svg` is a placeholder mark. The manifest in
  `vite.config.js` references `icons/icon-192.png` and `icons/icon-512.png`,
  which don't exist yet — export the SVG (or a real logo) to those two PNG
  sizes and drop them in `public/icons/` before shipping, or the install
  prompt will show a broken icon.
- **Image upload** on the แจ้งซ่อม form is a placeholder button; no file is
  actually attached yet.

## Deliberately not in Phase 1

Payment/accounting, e-Voting, visitor management, real-time chat,
marketplace, social feed, AI chatbot, smart home / IoT, CCTV integration,
multi-condo, multi-language, ERP. Add these later, once the core loop above
is in real use.
