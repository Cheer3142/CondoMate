import React from "react";
import { Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";

import ResidentLayout from "./pages/resident/ResidentLayout";
import ResidentHome from "./pages/resident/Home";
import ResidentRepair from "./pages/resident/Repair";
import ResidentParcel from "./pages/resident/Parcel";
import ResidentAnnounce from "./pages/resident/Announce";
import ResidentBooking from "./pages/resident/Booking";

import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminMaintenance from "./pages/admin/Maintenance";
import AdminParcel from "./pages/admin/Parcel";
import AdminAnnounce from "./pages/admin/Announce";
import AdminFacility from "./pages/admin/Facility";
import AdminResidents from "./pages/admin/Residents";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />

      <Route path="/resident" element={<ResidentLayout />}>
        <Route index element={<ResidentHome />} />
        <Route path="repair" element={<ResidentRepair />} />
        <Route path="parcel" element={<ResidentParcel />} />
        <Route path="announce" element={<ResidentAnnounce />} />
        <Route path="booking" element={<ResidentBooking />} />
      </Route>

      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminDashboard />} />
        <Route path="maintenance" element={<AdminMaintenance />} />
        <Route path="parcel" element={<AdminParcel />} />
        <Route path="announce" element={<AdminAnnounce />} />
        <Route path="facility" element={<AdminFacility />} />
        <Route path="residents" element={<AdminResidents />} />
      </Route>
    </Routes>
  );
}
