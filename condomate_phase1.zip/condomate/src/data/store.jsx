import React, { createContext, useContext, useEffect, useState } from "react";
import { seedState } from "./seed";

/**
 * Phase 1 data layer.
 *
 * Everything lives in React state, persisted to localStorage so a resident's
 * ticket/booking survives a page reload on their phone. There is no server
 * yet — every action below is a plain state update.
 *
 * To connect a real backend later: keep this same Context/hook shape, and
 * swap the body of each action for a fetch() call plus optimistic update.
 * Nothing outside this file needs to change.
 */

const STORAGE_KEY = "condomate.v1";
const DataContext = createContext(null);

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore corrupt/blocked storage and fall back to seed data
  }
  return seedState();
}

let idCounter = 2000;
const nextId = () => ++idCounter;

export function DataProvider({ children }) {
  const [data, setData] = useState(load);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // storage full or unavailable — app still works for this session
    }
  }, [data]);

  const actions = {
    addTicket: (t) =>
      setData((d) => ({ ...d, tickets: [{ id: nextId(), status: "new", note: "", ...t }, ...d.tickets] })),

    updateTicket: (id, patch) =>
      setData((d) => ({ ...d, tickets: d.tickets.map((t) => (t.id === id ? { ...t, ...patch } : t)) })),

    addParcel: (p) =>
      setData((d) => ({ ...d, parcels: [{ id: nextId(), ack: false, ...p }, ...d.parcels] })),

    ackParcel: (id) =>
      setData((d) => ({ ...d, parcels: d.parcels.map((p) => (p.id === id ? { ...p, ack: true } : p)) })),

    addAnnouncement: (a) =>
      setData((d) => ({ ...d, announcements: [{ id: nextId(), ...a }, ...d.announcements] })),

    deleteAnnouncement: (id) =>
      setData((d) => ({ ...d, announcements: d.announcements.filter((a) => a.id !== id) })),

    bookSlot: (key, room) =>
      setData((d) => ({ ...d, bookings: { ...d.bookings, [key]: room } })),

    updateFacility: (name, patch) =>
      setData((d) => ({ ...d, facilities: d.facilities.map((f) => (f.name === name ? { ...f, ...patch } : f)) })),

    resetDemoData: () => setData(seedState()),
  };

  return <DataContext.Provider value={{ data, ...actions }}>{children}</DataContext.Provider>;
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used inside <DataProvider>");
  return ctx;
}

// Signed-in resident for Phase 1 (no auth yet — one hardcoded unit).
export const CURRENT_ROOM = "A-1205";
export const CURRENT_NAME = "คุณเจมส์";
