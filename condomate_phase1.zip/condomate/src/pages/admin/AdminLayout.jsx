import React from "react";
import { NavLink, Outlet, Link } from "react-router-dom";
import { LayoutDashboard, Wrench, Package, Megaphone, Settings, Users, ArrowLeft } from "lucide-react";

const NAV = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/admin/maintenance", label: "แจ้งซ่อม", icon: Wrench },
  { to: "/admin/parcel", label: "พัสดุ", icon: Package },
  { to: "/admin/announce", label: "ประกาศ", icon: Megaphone },
  { to: "/admin/facility", label: "ส่วนกลาง", icon: Settings },
  { to: "/admin/residents", label: "ลูกบ้าน", icon: Users },
];

export default function AdminLayout() {
  return (
    <div style={{ minHeight: "100vh", display: "flex", justifyContent: "center", padding: 20 }}>
      <div className="cm-card" style={{ width: "100%", maxWidth: 960, minHeight: 640, display: "flex", overflow: "hidden", boxShadow: "0 12px 32px rgba(30,42,56,0.10)" }}>
        <div style={{ width: 190, background: "var(--ink)", padding: "20px 12px", display: "flex", flexDirection: "column", gap: 2 }}>
          <div className="cm-display" style={{ color: "#fff", fontWeight: 700, fontSize: 15, padding: "0 10px 6px" }}>นิติบุคคล</div>
          <Link to="/" style={{ display: "flex", alignItems: "center", gap: 6, color: "rgba(255,255,255,0.5)", fontSize: 11.5, textDecoration: "none", padding: "0 10px 14px" }}>
            <ArrowLeft size={12} /> เปลี่ยนมุมมอง
          </Link>
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              style={({ isActive }) => ({
                display: "flex", alignItems: "center", gap: 9, padding: "9px 10px", borderRadius: 8,
                fontSize: 13, fontWeight: 600, textDecoration: "none",
                background: isActive ? "rgba(255,255,255,0.12)" : "transparent",
                color: isActive ? "#fff" : "rgba(255,255,255,0.55)",
              })}
            >
              <Icon size={16} />{label}
            </NavLink>
          ))}
        </div>

        <div style={{ flex: 1, padding: 24, overflowY: "auto" }}>
          <Outlet />
        </div>
      </div>
    </div>
  );
}
