import React from "react";
import { Phone, Circle } from "lucide-react";
import { useData } from "../../data/store";
import SectionTitle from "../../components/SectionTitle";

export default function AdminResidents() {
  const { data } = useData();
  return (
    <div>
      <SectionTitle sub="รายชื่อลูกบ้านและสถานะสมาชิก">ลูกบ้าน</SectionTitle>
      <div className="cm-card" style={{ overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: "#F5F3EE", textAlign: "left" }}>
              {["ห้อง", "ชื่อ", "เบอร์โทร", "สถานะ"].map((h) => (
                <th key={h} style={{ padding: "10px 14px", fontSize: 11.5, color: "var(--ink-soft)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.03em" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.residents.map((r) => (
              <tr key={r.room} style={{ borderTop: "1px solid var(--line)" }}>
                <td className="cm-mono" style={{ padding: "10px 14px" }}>{r.room}</td>
                <td style={{ padding: "10px 14px", fontWeight: 600 }}>{r.name}</td>
                <td style={{ padding: "10px 14px", display: "flex", alignItems: "center", gap: 6, color: "var(--ink-soft)" }}><Phone size={12} />{r.phone}</td>
                <td style={{ padding: "10px 14px" }}>
                  <span style={{ fontSize: 11.5, fontWeight: 700, color: r.status === "สมาชิก" ? "var(--green)" : "var(--red)" }}>
                    <Circle size={7} style={{ marginRight: 5, fill: "currentColor", verticalAlign: "middle" }} />
                    {r.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
